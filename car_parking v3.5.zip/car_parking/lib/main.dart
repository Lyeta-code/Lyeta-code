
import 'package:car_parking/routes.dart';
import 'package:car_parking/screens/booking_screens/book_slot_page.dart';
import 'package:car_parking/screens/booking_screens/book_slot_three.dart';
import 'package:car_parking/screens/booking_screens/book_slot_two.dart';
import 'package:car_parking/screens/homepage_screen/homepage.dart';
import 'package:car_parking/screens/notification_screen/local_notification.dart';
import 'package:car_parking/screens/notification_screen/notification_info.dart';
import 'package:car_parking/screens/parkingList_screen/parkinglist.dart';
import 'package:car_parking/screens/parking_overview/parking_screen_three.dart';
import 'package:car_parking/screens/parking_overview/parking_screen_two.dart';
import 'package:car_parking/screens/sign_in/sign_in_screen.dart';
import 'package:car_parking/screens/sign_up/sign_up_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await LocalNotifications.init();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  //
  // verifyDurationBooking(){
  //   FirebaseFirestore.instance.collection("parkingNotification").where(field).get().then((value){
  //     if(value.docs.isNotEmpty){
  //       for(int i= 0; i<value.docs.length; i++){
  //         initMarker(value.docs[i].data(), value.docs[i].id);
  //       }
  //     }
  //   });
  // }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Car Parking',
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      // home: BookSlot(location: GeoPoint(0,0),),
      // initialRoute: ParkingListPage.routeName,
      // initialRoute: SignInScreen.routeName,
      initialRoute: HomepageScreen.routeName,
// home: MobilePay(duration: '', price: 0, paymentMode: '', identity: '', slot: '', stime: DateTime(2000
// ), etime: DateTime(2000
// ), location: GeoPoint(0,0), user: '', pBlock: ''),
//     home:  SignUpScreen(),
//     home: BookSlotTwo(location: const GeoPoint(0, 0)),
      routes: routes,
      debugShowCheckedModeBanner: false,
    );
  }
}

