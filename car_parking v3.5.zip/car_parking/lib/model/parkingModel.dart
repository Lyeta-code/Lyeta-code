
import 'package:google_maps_flutter/google_maps_flutter.dart';

class ParkingItem{
  int id;
  LatLng location;
  String title;
  String descriptions;
  ParkingItem(this.id, this.location, this.title, this.descriptions);


}