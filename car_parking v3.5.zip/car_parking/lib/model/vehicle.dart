import 'package:json_annotation/json_annotation.dart';

// This doesn't exist yet...! See "Next Steps"
// part 'user.g.dart';

@JsonSerializable(explicitToJson: true)
class User {
  User({
    required this.name,
    required this.age,
    required this.email,
  });

  final String name;
  final int age;
  final String email;
}



class Vehicle {
  String VehicleName, VehicleImage, VehicleReg;

  Vehicle(this.VehicleName, this.VehicleImage, this.VehicleReg);


}

// @Collection<User>('users')
// // @Collection<Address>('users/*/addresses')
// // final usersRef = UserCollectionReference();