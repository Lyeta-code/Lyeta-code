import 'package:dio/dio.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../screens/map_screen/parking_maps.dart';
import 'directions_model.dart';

class DirectionsRepository {
  static const String _baseUrl =
      'https://maps.googleapis.com/maps/api/directions/json?';

  final Dio _dio;

  DirectionsRepository({required Dio dio}) : _dio = dio ?? Dio();

  Future<Directions?> getDirections({
    required LatLng origin,
    required LatLng destination,
  }) async {
    Response response = await _dio.get(_baseUrl, queryParameters: {
      'origin': '${origin.latitude}.${origin.longitude}',
      'destination': '${destination.latitude},${destination.longitude},',
      'key': ParkingMaps.google_api_key,
    });
    if (response.statusCode == 200) {
      return Directions.fromMap(response.data);
    }
    if (response.statusCode == 404) {
       print('NOt found');
    }
    // print('Magatala '+response.data);
    return null;
  }
}
