import 'dart:ui';

class Info {
  String infoName, subInfo, infoTime;
  final Color status;
  Info(this.infoName, this.subInfo, this.infoTime, this.status);


}