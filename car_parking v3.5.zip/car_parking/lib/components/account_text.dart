import 'package:flutter/material.dart';

import '../constants/constants.dart';

class AccountText extends StatelessWidget {
  String descriptions;
  String text;
  GestureTapCancelCallback onTap;
   AccountText({
    Key? key,this.text = "Sign Up ",this.descriptions ="Don’t have an account? ", required this.onTap
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
         Text(
          descriptions,
          style: TextStyle(fontSize: 16),
        ),
        GestureDetector(
          onTap: onTap,
          child:  Text(
            text,
            style: TextStyle(fontSize: 16, color: kPrimaryColor),
          ),
        ),
      ],
    );
  }
}
