


import 'package:flutter/cupertino.dart';

 class CoordText extends StatelessWidget{
   double size;
   final String text;
   final Color color;

   CoordText({super.key,this.size = 12, required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 110,
      child: Text(
        text,
        style: TextStyle(
            color: color,
            fontSize: size,
            fontWeight: FontWeight.bold
        ),
        overflow: TextOverflow.ellipsis,
      ),
    );
  }
}