import 'dart:ui';

import 'package:flutter/cupertino.dart';

class AppColor {
  AppColor._(); // Private constructor to prevent instantiation

  static const Color primaryColor = Color(0xFF2F39C5);
  static const Color secondaryColor = Color(0xFFFF9A9E);
  static const Color accentColor = Color(0xFFE0C3FC);

  static const Gradient linearGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      primaryColor,
      secondaryColor,
    ],
  );

  static const Gradient radialGradient = RadialGradient(
    center: Alignment.center,
    radius: 0.75,
    colors: [
      accentColor,
      secondaryColor,
    ],
  );
}