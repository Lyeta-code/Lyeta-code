
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../components/account_text.dart';
import '../../components/custom_surfix_icon.dart';
import '../../components/form_error.dart';
import '../../constants/constants.dart';
import '../sign_in/sign_in_screen.dart';

class SignUpScreen extends StatefulWidget {
  static String routeName = "/sign_up";
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {

final _formKey = GlobalKey<FormState>();
String? email;
String? id;
String? password;
String? confirm_password;
String? name;
bool remember = false;
final List<String?> errors = [];

  bool isLoading = false;

  bool _obscureText = true;

void addError({String? error}) {
  if (!errors.contains(error)) {
    setState(() {
      errors.add(error);
    });
  }
}

void removeError({String? error}) {
  if (errors.contains(error)) {
    setState(() {
      errors.remove(error);
    });
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sign Up"),
      ),
      body: SafeArea(
        child: SizedBox(
          width: double.infinity,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SingleChildScrollView(
              child:isLoading ?const Padding(
                padding: EdgeInsets.only(top: 300),
                child: Center(
                    child: CircularProgressIndicator()),
              ): Column(
                children: [
                  const SizedBox(height: 16),
                  const Text("Register Account", style: headingStyle),
                  const Text(
                    "Complete your details or continue \nwith social media",
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                   Form(
                        key: _formKey,
                        child: Column(
                            children: [
                            TextFormField(
                            keyboardType: TextInputType.name,
                            onSaved: (newValue) => name = newValue,
                        // onChanged: (value) {
                        //   if (value.isNotEmpty) {
                        //     removeError(error: kEmailNullError);
                        //   } else if (emailValidatorRegExp.hasMatch(value)) {
                        //     removeError(error: kInvalidEmailError);
                        //   }
                        //   return;
                        // },
                        validator: (value) {
                          if (value!.isEmpty) {
                            addError(error: kNamelNullError);
                            return "";
                          }
                          return null;
                        },
                        decoration: const InputDecoration(
                          labelText: "Full Name",
                          hintText: "Enter your full name",
                          // If  you are using latest version of flutter then lable text and hint text shown like this
                          // if you r using flutter less then 1.20.* then maybe this is not working properly
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          prefixIcon: CustomSurffixIcon(svgIcon: "assets/icons/User.svg"),
                        ),
                      ),
                      TextFormField(
                        keyboardType: TextInputType.emailAddress,
                        onSaved: (newValue) => email = newValue,
                        onChanged: (value) {
                          if (value.isNotEmpty) {
                            removeError(error: kEmailNullError);
                          } else if (emailValidatorRegExp.hasMatch(value)) {
                            removeError(error: kInvalidEmailError);
                          }
                          return;
                        },
                        validator: (value) {
                          if (value!.isEmpty) {
                            addError(error: kEmailNullError);
                            return "";
                          } else if (!emailValidatorRegExp.hasMatch(value)) {
                            addError(error: kInvalidEmailError);
                            return "";
                          }
                          return null;
                        },
                        decoration: const InputDecoration(
                          labelText: "Email",
                          hintText: "Enter your email",
                          // If  you are using latest version of flutter then lable text and hint text shown like this
                          // if you r using flutter less then 1.20.* then maybe this is not working properly
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          prefixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Mail.svg"),
                        ),
                      ),
                      const SizedBox(height: 20),
                              TextFormField(
                                keyboardType: TextInputType.name,
                                onSaved: (newValue) => id = newValue,
                                onChanged: (value) {
                                  if (value.isNotEmpty) {
                                    removeError(error: kIdNullError);
                                  }
                                  return;
                                },
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    addError(error: kIdNullError);
                                    return "";
                                  }
                                  return null;
                                },
                                decoration: const InputDecoration(
                                  labelText: "Card ID",
                                  hintText: "Enter your Card ID",
                                  // If  you are using latest version of flutter then lable text and hint text shown like this
                                  // if you r using flutter less then 1.20.* then maybe this is not working properly
                                  floatingLabelBehavior: FloatingLabelBehavior.always,
                                  prefixIcon: Icon(Icons.credit_card),
                                ),
                              ),
                              const SizedBox(height: 20),
                      TextFormField(
                        obscureText: _obscureText,
                        onSaved: (newValue) => password = newValue,
                        onChanged: (value) {
                          if (value.isNotEmpty) {
                            removeError(error: kPassNullError);
                          } else if (value.length >= 8) {
                            removeError(error: kShortPassError);
                          }
                          password = value;
                        },
                        validator: (value) {
                          if (value!.isEmpty) {
                            addError(error: kPassNullError);
                            return "";
                          } else if (value.length < 8) {
                            addError(error: kShortPassError);
                            return "";
                          }
                          return null;
                        },
                        decoration:  InputDecoration(
                          labelText: "Password",
                          hintText: "Enter your password",
                          // If  you are using latest version of flutter then lable text and hint text shown like this
                          // if you r using flutter less then 1.20.* then maybe this is not working properly
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          prefixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Lock.svg"),
                          suffixIcon: IconButton(
                              onPressed: (){
                                setState(() {
                                  _obscureText =! _obscureText;
                                });
                          },
                              icon: _obscureText == true ?Icon(Icons.visibility_off):Icon(Icons.visibility))
                        ),
                      ),
                      const SizedBox(height: 20),
                      TextFormField(
                        obscureText: _obscureText,
                        onSaved: (newValue) => confirm_password = newValue,
                        onChanged: (value) {
                          if (value.isNotEmpty) {
                            removeError(error: kPassNullError);
                          } else if (value.isNotEmpty && password == confirm_password) {
                            removeError(error: kMatchPassError);
                          }
                          confirm_password = value;
                        },
                        validator: (value) {
                          if (value!.isEmpty) {
                            addError(error: kPassNullError);
                            return "";
                          } else if ((password != value)) {
                            addError(error: kMatchPassError);
                            return "";
                          }
                          return null;
                        },
                        decoration: const InputDecoration(
                          labelText: "Confirm Password",
                          hintText: "Re-enter your password",
                          // If  you are using latest version of flutter then lable text and hint text shown like this
                          // if you r using flutter less then 1.20.* then maybe this is not working properly
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          prefixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Lock.svg"),
                        ),
                      ),
                      FormError(errors: errors),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            _formKey.currentState!.save();
                            setState(() {
                              isLoading = true;
                            });

                            signUp(name.toString(),email.toString(),password.toString());

                            setState(() {
                              isLoading = false;
                            });
                          }
                        },
                        child: const Text("Continue"),
                      ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),
                  Text(
                    'By continuing your confirm that you agree \nwith our Term and Condition',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 20),
                  AccountText(descriptions: "Already I have an Account ",text: "Sign In",onTap: () { Navigator.pushNamed(context, SignInScreen.routeName); },),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
signUp(name,emailAddress,password) async {
  try {
    final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
      email: emailAddress,
      password: password,
    ).then((value) {
      FirebaseFirestore.instance.collection("carParkingUsers").add({
        'email':email,
        'cardID':id,
      });
      Navigator.pushNamed(context, SignInScreen.routeName);
    }
    );
  } on FirebaseAuthException catch (e) {
    if (e.code == 'weak-password') {
      print('The password provided is too weak.');
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("email-already-in-use"),

          )
      );
    } else {
      {
        Fluttertoast.showToast(msg: e.code,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
      }
    }
  } catch (e) {
    print(e);
  }
}
}
