import 'package:car_parking/components/app_large_text.dart';
import 'package:car_parking/components/app_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';

class InvoiceParking extends StatefulWidget {
  final String bookID;
  const InvoiceParking({super.key, required this.bookID});

  @override
  State<InvoiceParking> createState() => _InvoiceParkingState();
}

class _InvoiceParkingState extends State<InvoiceParking> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          height: MediaQuery.of(context).size.height-100,
          width: 350,
          child:  Column(
            children: [
              Icon(FontAwesomeIcons.parking,size: 80,),
              SizedBox(height: 10,),
              RichText(
                  text: const TextSpan(
                style: TextStyle(color: Colors.black54,
                fontWeight: FontWeight.bold,
                  fontSize: 18
                ),
                children:<TextSpan> [
                  TextSpan(
                    text: 'Mwanza, '
                  ),
                  TextSpan(text: "Nyerere road")
                ]
              )),
              const Text('Tel +255754-010203',style: TextStyle(color: Colors.black54,
                  fontWeight: FontWeight.bold,
                  fontSize: 20
              ),),
              const Divider(height: 30,),
              const SizedBox(height: 20,),
              AppLargeText(text: 'Parking Details',size: 26,),
              const SizedBox(height: 10,),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppLargeText(text: 'text',size: 22,),
                      AppText(text: 'text',size: 20,)
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppLargeText(text: 'DateTime',size: 22,),
                      AppText(text: DateFormat.yMd().format(DateTime.now()),size: 20,)
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppLargeText(text: 'Ticket No.',size: 22,),
                      AppText(text: 'PA12A',size: 20,)
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppLargeText(text: 'Vehicle Reg No',size: 22,),
                      AppText(text: 'T 234 ASD',size: 20,)
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppLargeText(text: 'Selected Slot',size: 22,),
                      AppText(text: '12A',size: 20,)
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppLargeText(text: 'Enter After',size: 22,),
                      AppText(text: '12:00',size: 20,)
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppLargeText(text: 'Exit Before',size: 22,),
                      AppText(text: '12:00',size: 20,)
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppLargeText(text: 'Paid By',size: 22,),
                      AppText(text: 'Mdukuzi',size: 20,)
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppLargeText(text: 'Amount Paid',size: 22,),
                      AppText(text: '2,000/=',size: 20,)
                    ],
                  ),
                  
                ],
              ),
              const SizedBox(height: 30,),
              // const Icon(FontAwesomeIcons.qrcode,size: 150,),
              TextButton(
                  onPressed: ()=> Navigator.pop(context),

                  child: const Text('OK',style: TextStyle(fontSize: 20,color: Colors.blue),)),

            ],
          ),

        ),
      ),
    );
  }

}
