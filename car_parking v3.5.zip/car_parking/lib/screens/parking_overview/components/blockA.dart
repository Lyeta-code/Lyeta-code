

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class blockA extends StatelessWidget{
  const blockA({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      // margin: const EdgeInsets.symmetric(horizontal: 4,vertical: 15),
      margin: const EdgeInsets.only(top: 15,right: 6),
      // padding: EdgeInsets.only(left: 10),
      decoration: const BoxDecoration(
        color: Colors.black26
      ),
      height: 500,
      width: 120,
    );
  }

}