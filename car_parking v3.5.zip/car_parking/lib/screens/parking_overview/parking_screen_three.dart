import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class parkingThree extends StatefulWidget {
  const parkingThree({super.key});

  @override
  State<parkingThree> createState() => _parkingThreeState();
}

class _parkingThreeState extends State<parkingThree> {
  final parkingLot = FirebaseFirestore.instance.collection('carParking');

  // .doc("parking_lot_01").collection("parkingBlock");
  final MyparkingLot = FirebaseFirestore.instance
      .collection('carParking')
      .doc("parking_lot_02")
      .collection("parkingBlock")
      .doc("block_01")
      .collection("parkingSlot");
  final Stream<QuerySnapshot> _usersStreamRight =
      FirebaseFirestore.instance.collection('parking').snapshots();
  final Stream<QuerySnapshot> _usersStream =
      FirebaseFirestore.instance.collection('users').snapshots();

  int selectedIndex = 0;
  int selectedIndexImage = 0;
  int selectedIndexDuration = 0;
  bool bookCar = true;
  bool bookCarRight = true;
  String bookSlot = '';
  int selectedBookIndex = 0;
  int selectedBookIndexRight = 0;
  int selectedPriceIndex = 0;
  String paymentMode = '';

  double Price = 500;
  String parkingBlock = '';
  String parking = '';
  String vehicleName = "Toyota Matrix";
  String vehicleRegNo = "HatchBack | T 123 ABC";
  String vehicleImage = "assets/images/car-icon3.jpg";
  String mySlot = "";
  String userName = "";
  String usernameSlotID = "";
  String usernameSlotIDRight = "";

  var price = {
    30: "500",
    60: "1000",
    120: "1500",
    300: "2000",
    720: "3000",
    1400: "5000",
  };
  var payment = {
    "mpesa.png": "M-Pesa",
    "tigopesa.png": "Tigo Pesa",
    "airtel.png": "Airtel Money",
    "halopesa.png": "Halo Pesa",
    "mastercard-2.png": "Mastercard",
    "google-pay.png": "Google Pay"
  };
  var vehicle = {
    "pick-up-car.png": "Pick-Up",
    "car-icon4.png": "Collora",
    "car-icon2.png": "Benz",
    "tractor.png": "Tractor",
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.local_parking),
      ),
      body:
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
        child: Stack(
          children: [
            Positioned(
              top: 25,
              child: Column(
                children: [
                  FutureBuilder(
                    future: parkingLot
                        .doc("parking_lot_02")
                        .collection("parkingBlock")
                        .doc("block_01")
                        .collection("parkingSlot")
                        .get(),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.hasError) {
                        return const Text("Something went wrong");
                      }

                      if (snapshot.hasData == null) {
                        return const Text("Document does not exist");
                        // print(snapshot);
                      }

                      if (snapshot.connectionState == ConnectionState.done &&
                          snapshot.hasData) {
                        if (snapshot.hasError) {
                          return Center(
                            child: Text(
                              'An ${snapshot.error} occurred',
                              style: const TextStyle(
                                  fontSize: 18, color: Colors.red),
                            ),
                          );
                        } else if (snapshot.hasData) {
                          final List<DocumentSnapshot> documents =
                              snapshot.data.docs;
                          return Column(
                              children: documents.map((doc) {
                            return InkWell(
                                onTap: () {
                                  if (doc['isSlotAvailable'] == false) {
                                    setState(() {
                                      parking = 'parking_lot_02';
                                      parkingBlock = "block_01";
                                      bookCar = !bookCar;
                                      selectedBookIndex =
                                          documents.indexOf(doc);
                                      bookSlot = doc.id;
                                    });
                                  } else if (doc['isSlotAvailable'] == true) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                            content: Text("Already Booked")));
                                  }
                                },
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 15, horizontal: 35),
                                  child: Stack(
                                    children: [
                                      Transform.rotate(
                                        angle: 5.6,
                                        child: Container(
                                            decoration: BoxDecoration(
                                                color: bookCar && !doc['isSlotAvailable'] &&
                                                        selectedBookIndex ==
                                                            documents.indexOf(doc)
                                                    ? Colors.green
                                                    : !doc['isSlotAvailable']
                                                        ? Colors.transparent
                                                        : Colors.transparent),
                                            // decoration:  BoxDecoration(
                                            //   color: bookCar && !doc['isSlotAvailable']&& selectedBookIndex == documents.indexOf(doc)   ?Colors.transparent: Colors.green
                                            // ),
                                            child: Opacity(
                                              opacity:
                                                  doc['isSlotAvailable'] == true
                                                      ? 1
                                                      : 0,
                                              child: Image.asset(
                                                "assets/images/car-icon1.png",
                                                height: 100,
                                              ),
                                            )),
                                      ),
                                      Positioned(
                                        child: Visibility(
                                          visible: doc.id == usernameSlotID
                                              ? true
                                              : false,
                                          child: Stack(
                                            children: [
                                              Transform.rotate(
                                                angle: 5.6,
                                                child: Container(
                                                    decoration: BoxDecoration(
                                                        color: bookCar && !doc['isSlotAvailable'] &&
                                                                selectedBookIndex == documents.indexOf(doc)
                                                            ? Colors.green
                                                            : doc['isSlotAvailable']
                                                                ? Colors
                                                                    .transparent
                                                                : Colors
                                                                    .transparent),
                                                    // decoration:  BoxDecoration(
                                                    //   color: bookCar && !doc['isSlotAvailable']&& selectedBookIndex == documents.indexOf(doc)   ?Colors.transparent: Colors.green
                                                    // ),
                                                    child: Opacity(
                                                        opacity:
                                                            doc['isSlotAvailable'] ==
                                                                    true
                                                                ? 1
                                                                : 0,
                                                        child: Image.asset(
                                                          "assets/images/car-icon1.png",
                                                          height: 100,
                                                          color: Colors.red,
                                                        ))),
                                              ),
                                              Positioned(
                                                  right: 30,
                                                  top: 18,
                                                  child: Transform.rotate(
                                                    angle: 5.6,
                                                    child: const Text(
                                                      "My Car",
                                                      style: TextStyle(
                                                        fontSize: 30,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        color: Colors.white,
                                                      ),
                                                    ),
                                                  ))
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ));
                          }).toList());
                        }
                      }

                      return const Center(
                        child: Padding(
                          padding: EdgeInsets.only(left: 60),
                          child: CircularProgressIndicator(),
                        ),
                      );
                    },
                  ),

                  // Column(
                  //
                  // // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  // children: List.generate(3, (index){
                  //   return InkWell(
                  //       onTap: (){
                  //         setState(() {
                  //
                  //         });
                  //       },
                  //       child: Padding(
                  //         padding: const EdgeInsets.symmetric(vertical: 15,horizontal: 35),
                  //         child: Container(
                  //           child: Transform.rotate(angle: 5.6,
                  //           child: Image.asset("assets/images/car-icon1.png",height: 100,)),
                  //         ),
                  //       )
                  //   );
                  // }),),
                ],
              ),
            ),
            Container(
              color: Colors.black12,
              child: Stack(
                children: [
                  Positioned(
                    top: 75,
                    left: 30,
                    child: Container(
                      color: Colors.black,
                      width: 9,
                      height: 470,
                    ),
                  ),
                  Positioned(
                    // left: 2,
                    right: 125,
                    // top: 20,
                    child: Column(
                      // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: List.generate(4, (index) {
                        return InkWell(
                            onTap: () {
                              setState(() {});
                            },
                            child: Transform.rotate(
                              angle: -120,
                              child: Visibility(
                                child: Container(
                                  margin: const EdgeInsets.only(
                                      right: 25, bottom: 130),
                                  color: Colors.black38,
                                  width: 200,
                                  height: 5,
                                ),
                              ),
                            ));
                      }),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
