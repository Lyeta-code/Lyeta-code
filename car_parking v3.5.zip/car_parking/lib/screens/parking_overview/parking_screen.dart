import 'package:car_parking/components/app_large_text.dart';
import 'package:flutter/material.dart';

class Parking extends StatefulWidget {
  static String routeName = "/parking_lot";
  const Parking({super.key});

  @override
  State<Parking> createState() => _ParkingState();
}

class _ParkingState extends State<Parking> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            AppLargeText(text: "Parking Area"),
            Stack(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 20),
                      child: Image.asset("assets/images/parking-space.png")),
                   Container(
                     margin: EdgeInsets.symmetric(horizontal: 25,vertical: 17),
                     child: Row(
                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                       children: [
                         Column(
                          // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: List.generate(6, (index){
                            return InkWell(
                              onTap: (){
                                setState(() {

                                });
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 4,horizontal: 9),
                                child: Image.asset("assets/images/car-icon1.png",height: 60,),
                              )
                            );
                          }),
                         ),
                         Column(
                           // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                           children: List.generate(6, (index){
                             return InkWell(
                                 onTap: (){
                                   setState(() {

                                   });
                                 },
                                 child: Padding(
                                   padding: const EdgeInsets.symmetric(vertical: 4,horizontal: 9),
                                   child: Image.asset("assets/images/car-icon1.png",height: 60,),
                                 )
                             );
                           }),
                         ),
                       ],
                     ),
                   ),

                ])


          ],
        ),
      ),
    );
  }
}
