import 'package:car_parking/screens/parking_overview/components/blockA.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class parkingTwo extends StatefulWidget {
  const parkingTwo({super.key});

  @override
  State<parkingTwo> createState() => _parkingTwoState();
}

class _parkingTwoState extends State<parkingTwo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Parking'),
      ),
      body: Container(
        // height: MediaQuery.of(context).size.height,
        color: Colors.black54,
        child: Stack(
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 86),
              child: Column(
                children: [
                  Row(
                    children: [
                      const blockA(),
                      Container(
                        height: 500,
                        width: 170,
                        decoration: const BoxDecoration(
                            // border: Border(left: BorderSide(color: Colors.black,width: 5),
                            //
                            // top: BorderSide(color: Colors.black,width: 5),
                            // bottom: BorderSide(color: Colors.black,width: 5))
                            ),
                        // color: Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Column(
                            children: [
                              Column(
                                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: List.generate(2, (index) {
                                  return InkWell(
                                      onTap: () {
                                        setState(() {});
                                      },
                                      child: Visibility(
                                        child: Stack(
                                          children: [
                                            Container(
                                              margin: const EdgeInsets.only(
                                                  bottom: 5),
                                              color: Colors.black38,
                                              // width: 200,
                                              height: 140,
                                            ),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      vertical: 15,
                                                      horizontal: 10),
                                              child: Image.asset(
                                                "assets/images/car-icon1.png",
                                                height: 100,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ));
                                }),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width,
                                height: 200,
                                decoration: const BoxDecoration(
                                  color: Colors.black,
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      blockA(),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              height: 100,
              margin: const EdgeInsets.symmetric(horizontal: 6),
              // padding: EdgeInsets.only(bottom: 200),
              decoration: const BoxDecoration(color: Colors.black26),
            ),
          ],
        ),
      ),
    );
  }
}
