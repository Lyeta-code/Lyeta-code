import 'dart:async';
import 'dart:ui' as ui;
import 'package:car_parking/components/Coord_text.dart';
import 'package:car_parking/components/app_large_text.dart';
import 'package:car_parking/components/app_text.dart';
import 'package:car_parking/screens/booking_screens/book_slot_page.dart';
import 'package:car_parking/screens/booking_screens/book_slot_three.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';

import '../../model/directions_model.dart';
import '../booking_screens/book_slot_two.dart';

class ParkingMaps extends StatefulWidget {
  final String identity;
  String pName;
  String pDescriptions;
  GeoPoint parkingLocation;
  bool showBottomSheet;
  static String routeName = "/parkingMap";
  static const String google_api_key = "AIzaSyCROHOCo0uLGvpFCuJJVPlvoFZmxJy723Y";

  ParkingMaps(
      {super.key,
      this.parkingLocation =
          const GeoPoint(2.5080481459689117, 32.90080090150512),
      required this.identity,
      this.pName = '',
      this.pDescriptions = '',
      this.showBottomSheet = false});

  @override
  State<ParkingMaps> createState() => _ParkingMapsState();
}

class _ParkingMapsState extends State<ParkingMaps> {
  bool _isLoading = false;
  final Completer<GoogleMapController> _controller = Completer();
  late Future<GoogleMapController> mapController;
  final Set<Polyline> _polyline = {};
  Directions? _info=null;

  // GoogleMapController? myController = await _controller.future;
  GoogleMapController? myController;
  final List<Marker> parkingList = [
    const Marker(
        markerId: MarkerId("first"),
        position: LatLng(-2.507928, 32.901305),
        infoWindow: InfoWindow(title: "My Position")),
    const Marker(
        markerId: MarkerId("Second"),
        position: LatLng(-2.507939, 32.904132),
        infoWindow: InfoWindow(title: "My Second Position"))
  ];
   LatLng? myLocation;



//Initialization of Marker
  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  Map<PolylineId, Polyline> polylines = {};
  List<LatLng> polylineCoordinates = [];
  PolylinePoints polylinePoints = PolylinePoints();
  LocationData? currentLocation;
  //  LocationData? currentLocation = LocationData.fromMap(
  //     {"latitude": -6.813006584796579, "longitude": 39.263729594759965});
  List<LatLng> latlng = [
    const LatLng(-6.813006584796579, 39.263729594759965),
    // const LatLng(6.8110315993222255, 39.226176819605385),
    const LatLng(-6.786642678849986, 39.215759914766394),
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCurrentLocation();
    packLocationData();
    getMarkerData();
    mapController = _createMapController();
    // animateCamera();

    // getPolyPoints();

// _polyline.add(Polyline(polylineId: const PolylineId('one'),
// points: latlng,
// ),
//
// );
    // myParkingMarker.addAll(parkingList);
  }


  _addPolyLine() {
    PolylineId id = PolylineId("poly");
    Polyline polyline = Polyline(
        polylineId: id, color: Colors.red, points: polylineCoordinates);
    polylines[id] = polyline;
    setState(() {});
  }
  animateCam(){
    if(_info != null){
      myController?.animateCamera(CameraUpdate.newLatLngBounds(_info!.bounds,100));
    }
    else{
      myController?.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(widget.parkingLocation.latitude, widget.parkingLocation.longitude),
        zoom: 11.5,

      )));
    }
  }

 showPolyline(LatLng myLocation) async {
   PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
     googleApiKey: ParkingMaps.google_api_key,
     request: PolylineRequest(
       origin: PointLatLng(myLocation.latitude, myLocation.longitude),
       destination: PointLatLng(widget.parkingLocation.latitude, widget.parkingLocation.longitude),
       mode: TravelMode.driving,
       // wayPoints: [PolylineWayPoint(location: "Sabo, Yaba Lagos Nigeria")],
     ),
   );
   if (result.points.isNotEmpty) {
     result.points.forEach((PointLatLng point) {
       polylineCoordinates.add(LatLng(point.latitude, point.longitude));
     });
   }
   _addPolyLine();

 }

  Future<GoogleMapController> _createMapController() async {
    Completer<GoogleMapController> _controller1 = Completer();
    return _controller1.future;
  }

  Future<Uint8List> forLoadingNetworkImage(String path) async {
    final completer = Completer<ImageInfo>();
    var image = AssetImage(path);

    image.resolve(const ImageConfiguration()).addListener(
        ImageStreamListener((info, _) => completer.complete(info)));
    final imageInfo = await completer.future;
    final byteData =
        await imageInfo.image.toByteData(format: ui.ImageByteFormat.png);
    return byteData!.buffer.asUint8List();
  }


  Future<Position> getUserLocation() async {
    await Geolocator.requestPermission()
        .then((value) {})
        .onError((error, stackTrace) {
      print('error $error');
    });
    return await Geolocator.getCurrentPosition();
  }
  packLocationData() {

    getUserLocation().then((value) async {
      Uint8List? image =
          await forLoadingNetworkImage('assets/images/car-icon2.png');
      final ui.Codec imageCodecMaker = await ui.instantiateImageCodec(
        image.buffer.asUint8List(),
        targetHeight: 130,
        targetWidth: 100,
      );

      final ui.FrameInfo frameInfo = await imageCodecMaker.getNextFrame();
      final ByteData? byteData =
          await frameInfo.image.toByteData(format: ui.ImageByteFormat.png);
      final Uint8List imageMarkerResizedCar = byteData!.buffer.asUint8List();

      Map<MarkerId, Marker> myMarker = <MarkerId, Marker>{
        const MarkerId('my Location'): Marker(
            markerId: const MarkerId('my Location'),
            position: LatLng(value.latitude, value.longitude),
            infoWindow: const InfoWindow(
              title: 'My Location',
              // snippet: specify['pDescription'],
            ),
            // icon: BitmapDescriptor.fromBytes(imageMarkerResizedCar),
            icon: BitmapDescriptor.defaultMarker),
      };


      setState(() {
        myLocation = LatLng(value.latitude, value.longitude);
        markers.addAll(myMarker);
        showPolyline(myLocation!);
        animateCamera();
      });
    });
  }


  // Marker Image
  Future<void> initMarker(specify, specifyId) async {
    Uint8List? image =
        await forLoadingNetworkImage('assets/images/parking-locator.png');
    final ui.Codec imageCodecMaker = await ui.instantiateImageCodec(
      image.buffer.asUint8List(),
      targetHeight: 130,
      targetWidth: 140,
    );

    final ui.FrameInfo frameInfo = await imageCodecMaker.getNextFrame();
    final ByteData? byteData =
        await frameInfo.image.toByteData(format: ui.ImageByteFormat.png);
    final Uint8List imageMarkerResized = byteData!.buffer.asUint8List();

    var markerIdVal = specifyId;
    final MarkerId markerId = MarkerId(markerIdVal);
    final Marker marker = Marker(
      markerId: markerId,
      position:
          LatLng(specify['pLocation'].latitude, specify['pLocation'].longitude),
      infoWindow: InfoWindow(
        title: specify['pName'],
        snippet: specify['pDescription'],
        // anchor: const Offset(0,6),
        onTap: () => BookingSheet(),
      ),
      icon: BitmapDescriptor.fromBytes(imageMarkerResized),
    );

    setState(() {
      markers[markerId] = marker;
    });
  }

  getMarkerData() {
    FirebaseFirestore.instance.collection("carParking").get().then((value) {
      if (value.docs.isNotEmpty) {
        for (int i = 0; i < value.docs.length; i++) {
          initMarker(value.docs[i].data(), value.docs[i].id);
        }
      }
    });
  }

  animateCamera() {
    Future.delayed(const Duration(seconds: 2), () async {
      // code to be executed after 2 seconds
      myController = await _controller.future;
      myController?.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(widget.parkingLocation.latitude,
              widget.parkingLocation.longitude),
          zoom: 14.5,
          tilt: 50
        ),
      ));
      if (widget.showBottomSheet == true) {
        Future.delayed(const Duration(seconds: 5), () async {
          BookingSheet();
        });
      }
    });
  }



  Future<LocationData?> getCurrentLocation() async {
    Location location = Location();
    GoogleMapController googleMapController = await _controller.future;

    // try {
      location.getLocation().then(
              (location) {
          currentLocation = location;

      });
      location.onLocationChanged.listen((newLoc) async {
        currentLocation = newLoc;
        googleMapController.animateCamera(CameraUpdate.newCameraPosition(
            CameraPosition(
                target: LatLng(newLoc.latitude!, newLoc.longitude!),
            zoom: 13.5,
            ))
        );


// final directions = await DirectionsRepository(dio: Dio())
//             .getDirections(origin: LatLng(double.parse(newLoc.latitude.toString()), double.parse(newLoc.longitude.toString())),
//             destination: LatLng(widget.parkingLocation.latitude, widget.parkingLocation.longitude));
//

        setState(() async {}
        );
      });
    // } on PlatformException catch (e) {
    //   if (e.code == 'PERMISSION_DENIED') {
    //     String error = 'please grant permission';
    //     print(error);
    //   }
    //   if (e.code == 'PERMISSION_DENIED_NEVER_ASK') {
    //     String error = 'permission denied- please enable it from app settings';
    //     print(error);
    //   }
    //   currentLocation = null;
    // }

    return currentLocation;
  }
  // @override
  // void dispose() {
  //   _controller.dispose();
  //   super.dispose();
  // }

  //
  // Future<void> getPolyPoints() async {
  //   PolylinePoints polylinePoints = PolylinePoints();
  //   PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
  //     googleApiKey: ParkingMaps.google_api_key,
  //     request: PolylineRequest(
  //       origin: const PointLatLng(-6.813006584796579, 39.263729594759965),
  //       destination: const PointLatLng(-6.786642678849986, 39.215759914766394),
  //       mode: TravelMode.driving,
  //       // wayPoints: [PolylineWayPoint(location: "Sabo, Yaba Lagos Nigeria")],
  //     ),
  //   );
  //   if (result.points.isNotEmpty) {
  //     result.points.forEach(
  //       (PointLatLng point) =>
  //           polylineCoordinates.add(LatLng(point.latitude, point.longitude)),
  //     );
  //     setState(() {});
  //   }
  //   print("MDUKUZI");
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: Visibility(
        visible: widget.showBottomSheet,
        child: FloatingActionButton(
          onPressed: () async {
            BookingSheet();
          },
          child: const Icon(Icons.add),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      body: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: myLocation == null
              ? const Center(child: CircularProgressIndicator())
              : GoogleMap(
                  mapType: MapType.normal,
                  scrollGesturesEnabled: true,
                  zoomControlsEnabled: true,
                  zoomGesturesEnabled: true,
                  compassEnabled: true,
                  markers: Set<Marker>.of(markers.values),
                  initialCameraPosition: CameraPosition(
                      target: LatLng(myLocation!.latitude, myLocation!.longitude),
                      zoom: 12),
                  onMapCreated: (GoogleMapController controller)async {
                    _controller.complete(controller);
                    // mapController = controller;
                  },
                  polylines: Set<Polyline>.of(polylines.values),
                  // polylines: {
                  //   Polyline(
                  //       polylineId: const PolylineId("overview_polyline"),
                  //       points: _info!.polylinePoints
                  //       .map((e) => LatLng(e.latitude, e.longitude)).toList(),
                  //       color: Colors.red,
                  //       width: 6)
                  // },
                  // _controller.complete(controller)
                ),
        ),
      ),
    );
  }

  void BookingSheet() {
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadiusDirectional.only(
          topEnd: Radius.circular(25),
          topStart: Radius.circular(25),
        ),
      ),
      builder: (context) => Container(
        padding: const EdgeInsetsDirectional.only(
          start: 10,
          end: 10,
          bottom: 30,
          top: 8,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 295,
              child: PageView(
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 2.5),
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      // crossAxisAlignment: CrossAxisAlignment.center,
                      // mainAxisSize: MainAxisSize.min,
                      children: [
                        AppLargeText(
                          text: widget.pName,
                          size: 20,
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          // crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            AppText(
                              text: "Rating",
                              color: Colors.black,
                              size: 16,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 42),
                              child: Wrap(
                                children: List.generate(5, (index) {
                                  return Icon(
                                    Icons.star,
                                    size: 14,
                                    color: index < 3
                                        ? Colors.yellow
                                        : Colors.white,
                                  );
                                }),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 2,
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          // crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 2,vertical: 8),
                              child: Row(
                                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  AppText(
                                    text: "Details",
                                    color: Colors.black,
                                    size: 14,
                                  ),
                                  const SizedBox(
                                    width: 33,
                                  ),
                                  SizedBox(
                                      width: MediaQuery.of(context).size.width-125,
                                      child: AppText(
                                        text: widget.pDescriptions,
                                        size: 12,
                                      )),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Row(
                              children: [
                                AppText(
                                  text: "Coordinates",
                                  color: Colors.black,
                                  size: 12,
                                ),
                                const SizedBox(
                                  width: 5,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: Row(
                                    children: [
                                      CoordText(
                                        text:
                                            ('${widget.parkingLocation.latitude} E'),
                                        color: Colors.green,
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      CoordText(
                                        text:
                                            ('${widget.parkingLocation.longitude} S'),
                                        color: Colors.green,
                                      ),
                                      // AppText(text: ('${widget.parkingLocation.latitude} EAST\t${widget.parkingLocation.longitude} SOUTH'),color: Colors.green,),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      // AppText(text: ('${widget.parkingLocation.latitude} EAST\n${widget.parkingLocation.longitude} SOUTH'),color: Colors.green,),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ],
                        ),
                        ElevatedButton(
                          onPressed: () {
                            if(widget.identity =='parking_lot_01'){
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => BookSlot(
                                          identity: widget.identity,
                                          location: widget.parkingLocation)));
                            }else if(widget.identity =='parking_lot_02'){
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => BookSlotThree(
                                          identity: widget.identity,
                                          location: widget.parkingLocation)));
                            }else if(widget.identity =='parking_lot_03'){
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => BookSlotTwo(
                                          identity: widget.identity,
                                          location: widget.parkingLocation)));
                            }else {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => BookSlot(
                                          identity: widget.identity,
                                          location: widget.parkingLocation)));
                            }

                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.deepOrangeAccent,
                            textStyle: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontStyle: FontStyle.normal),
                          ),
                          child: const Padding(
                            padding: EdgeInsets.fromLTRB(70, 10, 70, 10),
                            child: Text(
                              "Book Now",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
