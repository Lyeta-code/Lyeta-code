

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../components/account_text.dart';
import '../../components/custom_surfix_icon.dart';
import '../../components/form_error.dart';
import '../../constants/constants.dart';
import '../../helper/keyboard.dart';
import '../forgot_password/forgot_password_screen.dart';
import '../homepage_screen/homepage.dart';
import '../sign_up/sign_up_screen.dart';

class SignInScreen extends StatefulWidget {
  static String routeName = "/sign_in";

   SignInScreen({super.key});

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  bool isLoading = false;
  final _formKey = GlobalKey<FormState>();
  String? email;
  String? password;
  bool? remember = false;
  final List<String?> errors = [];

  bool _obscureText= true;



  void _isLoading(){
    setState(() {
      isLoading =! true;
    });
  }
  void addError({String? error}) {
    if (!errors.contains(error)) {
      setState(() {
        errors.add(error);
      });
    }
  }

  void removeError({String? error}) {
    if (errors.contains(error)) {
      setState(() {
        errors.remove(error);
      });
    }
  }


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text("Sign In"),
      ),
      body: SafeArea(
        child: SizedBox(
          width: double.infinity,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: SingleChildScrollView(
              child:isLoading ?const Padding(
                padding: EdgeInsets.only(top: 300),
                child: Center(
                    child: CircularProgressIndicator(color: Colors.red,)),
              ):
              Column(
                children: [
                  const SizedBox(height: 16),
                  const Text(
                    "Welcome Back",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Text(
                    "Sign in with your email and password  \nor continue with social media",
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  Form(
                    key: _formKey,
                    child: Column(
                        children: [
                        TextFormField(
                        keyboardType: TextInputType.emailAddress,
                        onSaved: (newValue) => email = newValue,
                          onChanged: (value) {
                      if (value.isNotEmpty) {
                        removeError(error: kEmailNullError);
                      } else if (emailValidatorRegExp.hasMatch(value)) {
                        removeError(error: kInvalidEmailError);
                      }
                      return;
                    },
                    validator: (value) {
                      if (value!.isEmpty) {
                        addError(error: kEmailNullError);
                        return "";
                      } else if (!emailValidatorRegExp.hasMatch(value)) {
                        addError(error: kInvalidEmailError);
                        return "";
                      }
                      return null;

                    },
                    decoration: const InputDecoration(
                      labelText: "Email",
                      hintText: "Enter your email",
                      // If  you are using latest version of flutter then lable text and hint text shown like this
                      // if you r using flutter less then 1.20.* then maybe this is not working properly
                      floatingLabelBehavior: FloatingLabelBehavior.always,
                      prefixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Mail.svg"),

                    ),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    obscureText: _obscureText,
                    onSaved: (newValue) => password = newValue,
                    onChanged: (value) {
                      if (value.isNotEmpty) {
                        removeError(error: kPassNullError);
                      } else if (value.length >= 8) {
                        removeError(error: kShortPassError);
                      }
                      return;
                    },
                    validator: (value) {
                      if (value!.isEmpty) {
                        addError(error: kPassNullError);
                        return "";
                      } else if (value.length < 8) {
                        addError(error: kShortPassError);
                        return "";
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      labelText: "Password",
                      hintText: "Enter your password",
                      // If  you are using latest version of flutter then lable text and hint text shown like this
                      // if you r using flutter less then 1.20.* then maybe this is not working properly
                      floatingLabelBehavior: FloatingLabelBehavior.always,
                      prefixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Lock.svg"),
                        suffixIcon: IconButton(
                            onPressed: (){
                              setState(() {
                                _obscureText =! _obscureText;
                              });
                            }, icon: _obscureText == true ?Icon(Icons.visibility_off):Icon(Icons.visibility))
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Checkbox(
                        value: remember,
                        activeColor: kPrimaryColor,
                        onChanged: (value) {
                          setState(() {
                            remember = value;
                          });
                        },
                      ),
                      const Text("Remember me"),
                      const Spacer(),
                      GestureDetector(
                        onTap: () => Navigator.pushNamed(
                            context, ForgotPasswordScreen.routeName),
                        child: const Text(
                          "Forgot Password",
                          style: TextStyle(decoration: TextDecoration.underline),
                        ),
                      )
                    ],
                  ),
                  FormError(errors: errors),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {

                      if (_formKey.currentState!.validate()) {

                        _formKey.currentState!.save();
                        // if all are valid then go to success screen
                        KeyboardUtil.hideKeyboard(context);
                        setState(() {
                          isLoading = true;
                        });
                        signIn(email.toString(), password.toString());
                        setState(() {
                          isLoading = false
                          ;
                        });
                        // Navigator.pushNamed(context, LoginSuccessScreen.routeName);
                      }
                    },
                    child: const Text("Continue"),
                  ),
                  ],
                ),
              ),
                  const SizedBox(height: 20),
                  AccountText(onTap: () { Navigator.pushNamed(context, SignUpScreen.routeName); },),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
  @override
  void initState() {
    // TODO: implement initState

    super.initState();
    // _checkUserLoggedIn();
  }
  final FirebaseAuth _auth = FirebaseAuth.instance;
  User? _user;
  void _checkUserLoggedIn(){
    _auth.authStateChanges().listen((User? user) {
      if(user == null){
        print('User is logged out');
        Navigator.pushNamed(context, SignInScreen.routeName);
      }else{
        print('User is logged in');
        // Navigator.pushNamed(context, HomepageScreen.routeName);
        _user = user;
      }
    });
  }
  Future<void> _signIn() async{
    try {
      UserCredential userCredential = await _auth.signInAnonymously();
      print('User logged in Anonymously');
    } catch (e) {
      print('Error signing in : $e');
    }
  }
  // Future<void> _signOut() async{
  //   final FirebaseAuth _auth = FirebaseAuth.instance;
  //   await _auth.signOut();
  //   print('User is logged out');
  // }

  signIn(emailAddress, password) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
          email: emailAddress,
          password: password
      ).then((value) =>
          Navigator.pushNamed(context, HomepageScreen.routeName));
      Fluttertoast.showToast(msg: "User is successfully signed in");
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        Fluttertoast.showToast(msg: 'No user found for that email.',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
        print('No user found for that email.');
      } else if (e.code == 'wrong-password') {

        Fluttertoast.showToast(msg: 'Wrong password provided for that user.',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
      }else {
        Fluttertoast.showToast(msg: e.code,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
      }

    }
  }
}
