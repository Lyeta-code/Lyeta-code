import 'package:car_parking/components/app_large_text.dart';
import 'package:car_parking/components/app_text.dart';
import 'package:car_parking/screens/parkingList_screen/parkinglist.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../../components/custom_surfix_icon.dart';
import '../../constants/constants.dart';
import '../../helper/keyboard.dart';

class MobilePay extends StatefulWidget {
  final String parking;
  final String slot;
  final String pBlock;
  final DateTime stime;
  final DateTime etime;
  final GeoPoint location;
  final String identity;
  final String duration;
  final double price;
  final String user;
  final String paymentMode;

  const MobilePay(
      {super.key,
      required this.duration,
      required this.price,
      required this.paymentMode,
      required this.identity,
      required this.slot,
      required this.stime,
      required this.etime,
      required this.location,
      required this.user,
      required this.pBlock,
      required this.parking});

  static String routeName = "/mobilePay";

  @override
  State<MobilePay> createState() => _MobilePayState();
}

class _MobilePayState extends State<MobilePay> {
  final List<String?> errors = [];
  String? phone;
  int selectedIndex = 0;
  late String mobilePay = widget.paymentMode;
  final _formKey = GlobalKey<FormState>();
  CollectionReference booking =
      FirebaseFirestore.instance.collection('Parking_Bookings');
  final parking = FirebaseFirestore.instance;
  final parkingLot = FirebaseFirestore.instance
      .collection('carParking')
      .doc("parking_lot_01")
      .collection("parkingBlock");
  var payment = {
    "mpesa.png": "M-Pesa",
    "tigopesa.png": "Tigo Pesa",
    "airtel.png": "Airtel Money",
    "halopesa.png": "Halo Pesa",
  };
  CollectionReference notification =
      FirebaseFirestore.instance.collection('carParking');

  Future<void> addNotification(String id) {
    // Call the user's CollectionReference to add a new user
    return notification
        .add({
          'title': 'New Booking', // John Doe
          'body':
              'Congratulation, You have Successfully Booked a Car parking Slot for ${widget.duration} minutes', // Stokes and Sons
          'hasReady': false,
          'bookId': id,
          'createdAt': DateTime.now(),
          'username': widget.user,
        })
        .then((value) => print("User Added"))
        .catchError((error) => print("Failed to add user: $error"));
  }

  addBooking(int phone, String parkingBlock) {
    return parking
        .collection("parkingBooking")
        .add({
          'id': widget.identity,
          'parkingLot': widget.parking,
          'parkingBlock': widget.pBlock,
          'SlotParking': widget.slot,
          'bookingId': bookid,
          'VehicleRegno': 'T 123 AMC',
          'startingAt': DateTime.timestamp(),
          'endingAt': DateTime.timestamp().add(Duration(
              minutes: int.parse(
                  widget.duration.replaceAll(RegExp(r'[^0-9]'), '')))),
          'location': widget.location,
          'paidAmount': widget.price,
          'username': widget.user,
          'phone': phone,
          'createdAt': DateTime.timestamp(),
          'status': true,
        })
        .then((value) => () {
              // _showDialog();
              print("Booking Added");
            })
        .catchError((error) => print("Failed to add a Booking: $error"));
  }

  // resetParking() {
  //   // return parking.collection('')
  //   parking
  //       .collection('carparking').
  //       .get()
  //       .then((QuerySnapshot querySnapshot) {
  //     querySnapshot.docs.forEach((doc) {
  //       print(doc["first_name"]);
  //     });
  //   });
  // }

  void addError({String? error}) {
    if (!errors.contains(error)) {
      setState(() {
        errors.add(error);
      });
    }
  }

  Future _showDialog() {
    return showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Congrats!"),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 100.0,
            ),
            SizedBox(height: 10.0),
            Text("Payment Successful!"),
          ],
        ),
        actions: <Widget>[
          TextButton(
              onPressed: () =>
                  Navigator.pushNamed(context, ParkingListPage.routeName),
              child: const Text('OK'))
        ],
      ),
    );
  }

  String bookid = Uuid().v4();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Deposit"),
      ),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppLargeText(
                    text: mobilePay,
                    size: 20,
                  ),
                  InkWell(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (_) => AlertDialog(
                                  content: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SingleChildScrollView(
                                        scrollDirection: Axis.vertical,
                                        child: Wrap(
                                          // spacing: 1.0,
                                          children: List.generate(
                                              payment.length, (index) {
                                            return InkWell(
                                              onTap: () {
                                                setState(() {
                                                  selectedIndex = index;
                                                  mobilePay = payment.values
                                                      .elementAt(index);
                                                });
                                                Navigator.pop(context);
                                              },
                                              child: Card(
                                                color: selectedIndex == index
                                                    ? Colors.lightGreen
                                                    : Colors.white24,
                                                child: Container(
                                                    padding: const EdgeInsets
                                                        .symmetric(
                                                        horizontal: 13,
                                                        vertical: 8),
                                                    decoration:
                                                        const BoxDecoration(),
                                                    margin:
                                                        const EdgeInsets.only(
                                                            right: 10),
                                                    child: Column(
                                                      children: [
                                                        Image.asset(
                                                          "assets/images/${payment.keys.elementAt(index)}",
                                                          height: 30,
                                                          fit: BoxFit.fill,
                                                        ),
                                                        AppText(
                                                            text: payment.values
                                                                .elementAt(
                                                                    index))
                                                      ],
                                                    )),
                                              ),
                                            );
                                          }),
                                        ),
                                      ),
                                    ],
                                  ),
                                ));
                      },
                      child: AppText(
                        text: "Change Payment Method",
                        size: 16,
                      ))
                ],
              ),
              const Divider(),
              Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  // crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AppLargeText(
                      text: "Amount Selected",
                      size: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: AppText(
                        text: widget.price.toString(),
                        size: 40,
                      ),
                    ),
                    Container()
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                keyboardType: TextInputType.phone,
                maxLength: 10,
                onSaved: (newValue) => phone = newValue,
                validator: (value) {
                  if (value!.isEmpty) {
                    addError(error: kPhoneNumberNullError);
                    return "";
                  }
                  return null;
                },
                decoration: InputDecoration(
                    labelText: "Phone Number",
                    hintText: "Enter $mobilePay Phone Number",
                    labelStyle: const TextStyle(
                        fontSize: 29,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                    suffixStyle: MaterialStateTextStyle.resolveWith((states) =>
                        const TextStyle(color: Colors.green, fontSize: 30)),
                    // If  you are using latest version of flutter then lable text and hint text shown like this
                    // if you r using flutter less then 1.20.* then maybe this is not working properly
                    floatingLabelBehavior: FloatingLabelBehavior.always,
                    // suffixIcon: const CustomSurffixIcon(svgIcon: "assets/icons/Phone.svg",),
                    suffixIcon: Icon(Icons.phone_iphone_outlined)),
              ),
              SizedBox(
                height: 20,
              ),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    // if all are valid then go to success screen
                    KeyboardUtil.hideKeyboard(context);
                    addBooking(int.parse(phone!), widget.pBlock);
                    addNotification(bookid);
                    // Navigator.pushNamed(context, LoginSuccessScreen.routeName);
                    _showDialog();
                  }
                },
                child: const Text(
                  "Book Now",
                  style: TextStyle(
                      fontSize: 18,
                      color: Colors.black54,
                      fontWeight: FontWeight.w500),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepOrange,
                  padding: EdgeInsets.symmetric(vertical: 5, horizontal: 100),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
