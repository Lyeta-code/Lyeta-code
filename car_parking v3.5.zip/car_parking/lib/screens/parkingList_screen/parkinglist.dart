import 'package:car_parking/components/app_large_text.dart';
import 'package:car_parking/screens/map_screen/parking_maps.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ParkingListPage extends StatefulWidget {
  const ParkingListPage({super.key});
  static String routeName = "/parkingList";
  @override
  State<ParkingListPage> createState() => _ParkingListPageState();
}

class _ParkingListPageState extends State<ParkingListPage> {

  final Stream<QuerySnapshot> _usersStream = FirebaseFirestore.instance.collection('carParking').snapshots();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          AppLargeText(text: "The list of Parking Nearby",size: 20,),
          SizedBox(
            height: MediaQuery.of(context).size.height-165,
            width: double.infinity,
            child: StreamBuilder<QuerySnapshot>(
            stream: _usersStream,
            builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.hasError) {
                return const Text('Something went wrong');
              }

              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                    child:  CircularProgressIndicator()
                );
              }
              return ListView(
                shrinkWrap: true,
                children: snapshot.data!.docs.map((DocumentSnapshot document) {
                  Map<String, dynamic> data = document.data()! as Map<String, dynamic>;

                  return InkWell(
                    onTap: (){
                      // Navigator.push(context, builder(ParkingMaps()));
                      // Navigator.pushNamed(context, ParkingMaps.routeName, parkingLocation: data['location']);
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>
                          ParkingMaps(
                            parkingLocation: data['pLocation'],
                            identity: document.id,
                            pDescriptions: data['pDescription'],
                            pName: data['pName'],
                            showBottomSheet: true,
                          )));
                    },
                    child: Card(
                      elevation: 8.0,
                      margin: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
                      child: Container(
                        decoration: const BoxDecoration(color: Color.fromRGBO(64, 75, 96, .9)),
                        child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 2.0),
                            leading: Container(
                              padding: const EdgeInsets.only(right: 12.0),
                              decoration:  const BoxDecoration(
                                  border:  Border(
                                      right:  BorderSide(width: 1.0, color: Colors.white24))),
                              child: const Icon(FontAwesomeIcons.squareParking, color: Colors.white,size: 48,),
                            ),
                            title:  Text(
                              data['pName'],
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                            ),
                            // subtitle: Text("Intermediate", style: TextStyle(color: Colors.white)),

                            subtitle:  Row(
                              children: <Widget>[
                                Wrap(
                                  children: List.generate(5, (index){
                                    return Icon(Icons.star,color: index<data['pRating'] ?Colors.yellow:Colors.white,);
                                  }),
                                ),
                                // Text(" Intermediate", style: TextStyle(color: Colors.white)
                                // )
                              ],
                            ),
                            trailing:
                            const Icon(Icons.keyboard_arrow_right, color: Colors.white, size: 30.0)),
                      ),
                    ),
                  );
                }).toList(),
              );

            },
                  ),
          ),
        ],
      )


    );
        }
}
