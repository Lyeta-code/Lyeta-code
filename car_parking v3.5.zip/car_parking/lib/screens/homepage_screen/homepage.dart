import 'dart:io';

import 'package:car_parking/screens/notification_screen/local_notification.dart';
import 'package:car_parking/screens/sign_in/sign_in_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';

import '../map_screen/parking_maps.dart';
import '../notification_screen/notification_info.dart';
import '../parkingList_screen/parkinglist.dart';
import '../sign_up/sign_up_screen.dart';

class HomepageScreen extends StatefulWidget {
  static String routeName = "/home";
  static String username = '';
  const HomepageScreen({super.key});

  @override
  State<HomepageScreen> createState() => _HomepageScreenState();
}

class _HomepageScreenState extends State<HomepageScreen> {

  final parkingBooking =
  FirebaseFirestore.instance.collection('parkingBooking');
  String name = '';
  String username = '';
  String email = '';
  String cardID = '';
  int _selectedIndex = 0;
  List pages = [
    const ParkingListPage(),
    ParkingMaps(identity: '',),
    const NotificationInfo(),
  ];
  @override
  void initState() {
    // TODO: implement initState
    // _checkUser();
    // verifyBooking();
    // confirmBooking();
    _checkUserLoggedIn();

    getParkingList();
    listenToNotifications();
    getBookingItem(email);

      super.initState();

  }
  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    checkParkingBooking();
  }
  checkParkingBooking()async{
    parkingBooking
        .where('username', isEqualTo: email)
        .where('status', isEqualTo: true )
        .get()
        .then((querySnapshot) {
      // print("Successfully completed");
      // print(querySnapshot.docs);
      for (var docSnapshot in querySnapshot.docs) {
        // print('${docSnapshot.id} => ${docSnapshot.data()}');
        print(docSnapshot.id);
        if(docSnapshot.data().isNotEmpty){
          if(docSnapshot.data()['endingAt'].compareTo(Timestamp.now())==-1){
            parkingBooking
          .doc(docSnapshot.id)
          .update({'status': false})
          .then((value) {
            print("Booking Updated");
            Fluttertoast.showToast(msg: "The Car Parking Booking that You booked on "
                "${docSnapshot.data()['createdAt']} Has Expired on ${docSnapshot.data()['endingAt']} and that Your "
                "booked for Tsh ${docSnapshot.data()['paidAmount']} Has Expired.",
                toastLength: Toast.LENGTH_LONG,
                gravity: ToastGravity.CENTER,
                timeInSecForIosWeb: 6,
                backgroundColor: Colors.red,
                textColor: Colors.white,
                fontSize: 16.0
            );
            })
          .catchError((error) => print("Failed to update Booking: $error"));
          }
          // if(docSnapshot.data()['createdAt']-DateTime.now())
          // print(docSnapshot.data()['createdAt']-DateTime.now());
          // print((docSnapshot.data()['createdAt']).compareTo(DateTime.timestamp()));
          Timestamp t = docSnapshot.data()['createdAt'] as Timestamp;
          // print(Timestamp.now().compareTo(Timestamp.fromDate(DateTime(2024,7,24))));
          print(Timestamp.fromDate(DateTime(2024,7,24,02,10)).compareTo(Timestamp.now()));
          // print(DateTime.timestamp().millisecondsSinceEpoch);
          // print(DateTime.timestamp().millisecondsSinceEpoch.compareTo(docSnapshot.data()['createdAt']));
          print('hali ni tete');
          print('${docSnapshot.id} => ${docSnapshot.data()['createdAt']}');
        }else{
          print('No Data Found');
        }
      }
    }
    );}
  String payload= '';
  listenToNotifications(){
    LocalNotifications.onClickNotification.stream.listen((event) {
      setState(() {
        payload = event;
      });
      _onItemTapped(2);
    });
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final verify = FirebaseFirestore.instance.collection("carParking");
  final booking = FirebaseFirestore.instance.collection("Parking_Bookings");

  Future<void> _checkUser()async {
    User?  name = _auth.currentUser;
      username = _auth.currentUser!.displayName!;
    email = _auth.currentUser!.email!;
setState(() {
  username == username;
  name == name;
  email == email;
});

    // print(name);
    // print(username);
    // print(username);
    // print(username);
  }
   checkCardId(){
    FirebaseFirestore.instance.collection('carParkingUsers').where('email', isEqualTo:email )
        .get()
        .then((querySnapshot) async {
      for (var docSnapshot in querySnapshot.docs) {
       String card = await docSnapshot.data()['cardID'];
       // print(card);
        setState(() {
          cardID = card;
        });
        print('KADI NI '+cardID);
        return docSnapshot.data()['cardID'];
      }
    });
  }
  void _checkUserLoggedIn(){

    _auth.authStateChanges().listen((User? user) {
      if(user == null){
        print('User is logged out');
        Navigator.pushNamed(context, SignInScreen.routeName);
      }else{
        print('User is logged in');
        // Navigator.pushNamed(context, HomepageScreen.routeName);
        User?  name = _auth.currentUser;
        username = _auth.currentUser!.email!;
        email = _auth.currentUser!.email!;
        setState(() {
          username == username;
          name == name;
          email == email;
        });
        checkCardId();
      }
    });
  }
  Future<void> _signOut() async{

    await _auth.signOut();
    print('User is logged out');
    Navigator.pushNamed(context, SignInScreen.routeName);
  }
getBookingItem(String username){
  booking.where('username', isEqualTo:username )
      .get()
      .then((QuerySnapshot querySnapshot) {
    querySnapshot.docs.forEach((doc) {
      // verifyParkingBlock(doc.id);
      // print(doc['username']);
      // print(doc['startingAt']);
      // print(doc['endingAt']);
      // print('The slot parking id ' +doc['slotParking']);
      compareTime(doc['parkingLot'], doc['blockParking'], doc['slotParking'], doc['endingAt']);
// compareTime(doc['endingAt']);
      // time = endingT.;
      // endingT-sta
// time = startT.difference(endingT);
//       if()
// print(p.c)
    });
  });
}
compareTime(String pID,String bID, String sID, var EndAt){
  final p = DateFormat("dd/mm/yy HH:mma:ss").format((DateTime.now()));
  final d = DateFormat("dd/mm/yy HH:mma:ss").format((EndAt).toDate());
  // final DateTime time, endingT = doc['endingAt'], startT= doc['startingAt'];
// print(p);
  var dateFormat =  DateFormat('dd/mm/yy hh:mm');
  DateTime durationStart =  dateFormat.parse(d);
  DateTime durationEnd =  dateFormat.parse(p);
  // final q = durationEnd.difference(durationStart);
  print("The duration is ${durationEnd.difference(durationStart).inMinutes}");
  // final t = dateFormat.parse('0:02');
  // final comparison = durationEnd.compareTo(durationStart);
  print('The comparison is ${durationEnd.compareTo(durationStart)}');
  if(durationEnd.difference(durationStart).inMinutes > 30){
    print("Hello");
    getParkingSlot(pID, bID, sID,false);
  }else{
    print("mdukuzi");
    getParkingSlot(pID, bID, sID,true);
  }
}
  getParkingList(){
    verify
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        // verifyParkingBlock(doc.id);
        getParkingBlock(doc.id);
      });
    });
  }

getParkingBlock(String pID){
  verify.doc(pID).collection('parkingBlock')
      .get()
      .then((QuerySnapshot querySnapshot) {
    querySnapshot.docs.forEach((doc) {
      // print(doc.id);
      // getParkingSlot(pID, doc.id,);
    });
  });
}
  // Future<void> verifyBooking()async {
  //   verify.get().then((value){
  //     if(value.docs.isNotEmpty){
  //       for(int i= 0; i<value.docs.length; i++){
  //         // verifyParkingBlock(value.docs.i)
  //         // initMarker(value.docs[i].data(), value.docs[i].id);
  //         // print(value.);
  //       }
  //     }
  //   });
  // }
  // Future<void> verifyParkingBlock(String pID,String bID)async {
  //
  //
  //   verify.doc(pID).collection(bID).get().then((value){
  //     if(value.docs.isNotEmpty){
  //       for(int i= 0; i<value.docs.length; i++){
  //         // initMarker(value.docs[i].data(), value.docs[i].id);
  //       }
  //     }
  //   });
  // }
  Future<void> getParkingBlockkk(String pID,String bID)async {
    verify.doc(pID).collection('parkingBlock').doc(bID).collection('parkingSlot')
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        print('THE SLOT IS '+doc.id);
        // getParkingSlot(pID, bID, doc.id);
      });
    });
  }
  
  Future<void> getParkingSlot(String pID,String bID,String sID, bool isSlotAvailable)async {
    verify.doc(pID).collection('parkingBlock').doc(bID).collection('parkingSlot')
        .doc(sID)
        .get()
        .then((DocumentSnapshot documentSnapshot) {
      if (documentSnapshot.exists) {
        Map<String, dynamic> data = documentSnapshot.data() as Map<String, dynamic>;
        // return Text("Full Name: ${data['full_name']} ${data['last_name']}");
        print(data['isSlotAvailable']);
        setParkingSlot(pID, bID, sID,isSlotAvailable);
      }
    });
  }
  // getParkingSlot(String pID,String bID, String sID){
  //   verify.doc(pID).collection('parkingBlock').doc(bID).collection('parkingSlot')
  //       .doc(sID)
  //       .get()
  //       .then((DocumentSnapshot documentSnapshot) {
  //     if (documentSnapshot.exists) {
  //       setParkingSlot(pID, bID, sID);
  //       // print('Document exists on the database');
  //       final slot = documentSnapshot.data();
  //       print(slot);
  //     }
  //   });
  // }
  Future<void> setParkingSlot(String pID, String bID, String sID, bool isSlotAvailable) {
    return verify.doc(pID).collection('parkingBlock').doc(bID).collection('parkingSlot')
        .doc(sID)
        .set({
      'isSlotAvailable': isSlotAvailable,
    })
        .then((value) => print("User Added"))
        .catchError((error) => print("Failed to add user: $error"));
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title:  Text('Car Parking'),
      ),
      drawer: Drawer(
        child: ListView(
          // Remove padding
          padding: EdgeInsets.zero,
          children: [
             UserAccountsDrawerHeader(
              accountName: Text(username),
              accountEmail: Text("$email | card ID: $cardID"),
              currentAccountPicture: const CircleAvatar(
                child: ClipOval(
                  child: Icon(FontAwesomeIcons.squareParking, color: Colors.white,size: 48,)
                ),
              ),
              decoration: const BoxDecoration(
                color: Colors.blue,
                image: DecorationImage(
                    fit: BoxFit.fill,
                    image: NetworkImage(
                        'https://oflutter.com/wp-content/uploads/2021/02/profile-bg3.jpg')),
              ),
            ),

            ListTile(
              leading: Icon(Icons.notifications_active_outlined),
              title: Text('Info'),
              onTap: () => _onItemTapped(2),
            ),
            ListTile(
              leading: Icon(Icons.map_sharp),
              title: Text('Maps'),
              onTap: () => _onItemTapped(1),
            ),
             ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
                onTap: () => _onItemTapped(0)
            ),
            ListTile(
                leading: Icon(Icons.home),
                title: Text('Now'),
                onTap: () {
                  LocalNotifications.showSimpleNotification(title: 'Simple Notification', body: 'Hali ni tete', payload: 'mambo si shwali');
                }
            ),

            Divider(),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Log Out'),
              onTap: () async {
                await _auth.signOut();
                print('User is logged out');
                Navigator.pushNamed(context, SignInScreen.routeName);
              },
            ),
            ListTile(
              title: Text('Exit'),
              leading: Icon(Icons.exit_to_app),
              onTap: () => exit(0),
            ),
          ],
        ),
      ),
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor:   Color(0xff2da9ef),
      // gradient: LinearGradient(
      //     colors: [Color(0xff0d70fe),Color(0xff2da9ef)],
      //     begin: Alignment.centerRight,
      //     end: Alignment(-1.0,-1.0)
      // ),
        elevation: 0,
        iconSize: 15,
        mouseCursor: SystemMouseCursors.grab,
        selectedFontSize: 13,
        selectedIconTheme: const IconThemeData(color: Colors.amberAccent, size: 17),
        selectedItemColor: Colors.amberAccent,
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
        currentIndex: _selectedIndex,
        unselectedIconTheme: const IconThemeData(
          color: Colors.white,

        ),
        unselectedItemColor: Colors.white,
        onTap: _onItemTapped,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(FontAwesomeIcons.squareParking),
            label: 'Parkings',
          ),
          BottomNavigationBarItem(
            icon: Icon(FontAwesomeIcons.mapLocation),
            label: 'Map',
          ),
          BottomNavigationBarItem(
            icon: Icon(FontAwesomeIcons.info),
            label: 'Info',
          ),
        ],
      ),
    );
  }
}
