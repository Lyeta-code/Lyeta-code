import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import '../../components/app_large_text.dart';
import '../../components/app_text.dart';
import '../../model/notification.dart';
import '../parkingList_screen/parkinglist.dart';

class NotificationInfo extends StatefulWidget {
  const NotificationInfo({super.key});
  static String routeName = "/notification";

  @override
  State<NotificationInfo> createState() => _NotificationInfoState();
}

class _NotificationInfoState extends State<NotificationInfo> {
  final List<Info> info =  [
    // Vehicle("Jeep", VehicleImage, VehicleReg)
  ];
  CollectionReference information = FirebaseFirestore.instance.collection('parkingNotification');
  CollectionReference invoice = FirebaseFirestore.instance.collection('carParking');
  @override

  void initState() {
    super.initState();
    setState(() {
      info.add(Info("New Booking", "Congratulation, You have placed a booking lot", "13:00", Colors.green),);
      info.add(Info("New Booking", "Congratulation, You have placed a booking lot", "12:00", Colors.blue),);
      info.add(Info("New Booking", "Congratulation, You have placed a booking lot", "11:00", Colors.red),);
      info.add(Info("New Booking", "Congratulation, You have placed a booking lot", "10:00", Colors.yellow),);
      info.add(Info("New Booking", "Congratulation, You have placed a booking lot", "01:00", Colors.black),);
    });
  }


  Future<QuerySnapshot<Object?>>getNotification(){
    CollectionReference information = FirebaseFirestore.instance.collection('parkingNotification');
    return information.get();
  }
  Future<DataSnapshot>getNotificationttt(){
    // CollectionReference information = FirebaseFirestore.instance.collection('parkingNotification');
    // return information.get();
    final commentsRef = FirebaseDatabase.instance.ref('parkingNotification');
    commentsRef.onChildAdded.listen((event) {
      // A new comment has been added, so add it to the displayed list.
    });
    return commentsRef.get();
  }
  Widget _myheaderContent(){
    return  Align(
      child: ListTile(
        leading: Text(
          DateTime.now().day.toString(),style: TextStyle(fontSize: 40,color: Colors.amber),
        ),
        // title: Text(DateTime.timestamp().subtract().toString(), style: TextStyle(fontSize: 24,color: Colors.white),),
        title: Text(DateFormat.MMM().format(DateTime.now()).toString(), style: TextStyle(fontSize: 24,color: Colors.white),),
        subtitle: Text(DateTime.now().year.toString(),style: TextStyle(fontSize: 14,color: Colors.white),),
      ),
    );
  }
  Widget _myListContainer(String infoname, String subinfo, Timestamp infoTime, Color infoColor){
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2,horizontal: 8),
      child: InkWell(
        onTap: (){

              showDialog(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text("Notifications"),
                  content: Row(
// mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      const Icon(
                        Icons.notification_important,
                        color: Colors.blueGrey,
                        size: 60.0,
                      ),
                      // SizedBox(height: 10.0),
                      const SizedBox(width: 5,),
                      Container(
                          width: MediaQuery.of(context).size.width-200,
                          child: Text(subinfo,style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),)),
                    ],
                  ),
                  actions: <Widget>[
                    TextButton(
                        onPressed: (){


                          showDialog(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                icon: Icon(FontAwesomeIcons.parking,size: 80,),
                                  title: Center(
                                    child: Column(
                                      children: [
                                        RichText(
                                            text: const TextSpan(
                                                style: TextStyle(color: Colors.black54,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 18
                                                ),
                                                children:<TextSpan> [
                                                  TextSpan(
                                                      text: 'Mwanza, '
                                                  ),
                                                  TextSpan(text: "Nyerere road")
                                                ]
                                            )),
                                        const Text('Tel +255754-010203',style: TextStyle(color: Colors.black54,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20
                                        ),),
                                        const Divider(height: 50,),
                                      ],
                                    ),
                                  ),
                                  content: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      AppLargeText(text: 'Parking Details',size: 20,),

                                      FutureBuilder<QuerySnapshot>(
                                          future: getNotification(),
                                          builder:
                                              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                                            if (snapshot.hasError) {
                                              return const Text("Something went wrong");
                                            }

                                            // if (snapshot.hasData && !snapshot.data!.exists) {
                                            //   return const Text("Document does not exist");
                                            // }

                                            if (snapshot.connectionState == ConnectionState.done) {
                                              final List<DocumentSnapshot> documents = snapshot.data!.docs;
                                              return ListView(
                                                  shrinkWrap: true,
                                                  children: documents
                                                      .map((doc) {
                                                    return
                                                      Column(
                                                        children: [
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            children: [
                                                              AppLargeText(text: 'text',size: 18,),
                                                              AppText(text: 'text',size: 14,)
                                                            ],
                                                          ),
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            children: [
                                                              AppLargeText(text: 'DateTime',size: 18,),
                                                              AppText(text: DateFormat.yMd().format(DateTime.now()),size: 14,)
                                                            ],
                                                          ),
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            children: [
                                                              AppLargeText(text: 'Ticket No.',size: 18,),
                                                              AppText(text: 'PA12A',size: 14,)
                                                            ],
                                                          ),
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            children: [
                                                              AppLargeText(text: 'Vehicle Reg No',size: 18,),
                                                              AppText(text: 'T 234 ASD',size: 14,)
                                                            ],
                                                          ),
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            children: [
                                                              AppLargeText(text: 'Selected Slot',size: 18,),
                                                              AppText(text: '12A',size: 14,)
                                                            ],
                                                          ),
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            children: [
                                                              AppLargeText(text: 'Enter After',size: 18,),
                                                              AppText(text: '12:00',size: 14,)
                                                            ],
                                                          ),
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            children: [
                                                              AppLargeText(text: 'Exit Before',size: 18,),
                                                              AppText(text: '12:00',size: 14,)
                                                            ],
                                                          ),
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            children: [
                                                              AppLargeText(text: 'Paid By',size: 18,),
                                                              AppText(text: 'Mdukuzi',size: 14,)
                                                            ],
                                                          ),
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            children: [
                                                              AppLargeText(text: 'Amount Paid',size: 18,),
                                                              AppText(text: '2,000/=',size: 14,)
                                                            ],
                                                          ),

                                                        ],
                                                      );


                                                  }
                                                  )
                                                      .toList());
                                            }
                                            return const Center(
                                                child:  CircularProgressIndicator()
                                            );

                                          }
                                      ),



                                      Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              AppLargeText(text: 'text',size: 18,),
                                              AppText(text: 'text',size: 14,)
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              AppLargeText(text: 'DateTime',size: 18,),
                                              AppText(text: DateFormat.yMd().format(DateTime.now()),size: 14,)
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              AppLargeText(text: 'Ticket No.',size: 18,),
                                              AppText(text: 'PA12A',size: 14,)
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              AppLargeText(text: 'Vehicle Reg No',size: 18,),
                                              AppText(text: 'T 234 ASD',size: 14,)
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              AppLargeText(text: 'Selected Slot',size: 18,),
                                              AppText(text: '12A',size: 14,)
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              AppLargeText(text: 'Enter After',size: 18,),
                                              AppText(text: '12:00',size: 14,)
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              AppLargeText(text: 'Exit Before',size: 18,),
                                              AppText(text: '12:00',size: 14,)
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              AppLargeText(text: 'Paid By',size: 18,),
                                              AppText(text: 'Mdukuzi',size: 14,)
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              AppLargeText(text: 'Amount Paid',size: 18,),
                                              AppText(text: '2,000/=',size: 14,)
                                            ],
                                          ),

                                        ],
                                      ),
                                    ],
                                  ),
                                  actions: <Widget>[
                                    // TextButton(
                                    //     onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (context){
                                    //       // return
                                    //       // InvoiceParking();
                                    //
                                    //     })),
                                    //
                                    //     child: const Text('VIEW ONVOICE')),
                                    TextButton(
                                        onPressed: ()=> Navigator.pop(context),

                                        child: const Text('OK')),

                                  ]
                              )
                          );
              },

                        child: const Text('VIEW INVOICE')),
                    TextButton(
                        onPressed: ()=> Navigator.pop(context),

                        child: const Text('OK')),

                  ],
                ),
              );


        },
        child: Container(
          height: 60.0,
          child: Material(
            color: Colors.white,
            elevation: 14.0,
            shadowColor: const Color(0x802196F3),
            child: Row(
              children: <Widget>[
                Container(
                  height: 40.0,
                  width: 10.0,
                  color: infoColor,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(6.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            child: Text(infoname, style: const TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                                fontWeight: FontWeight.bold)),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: MediaQuery.of(context).size.width-180,
                            child: Text(subinfo, style: const TextStyle(
                                fontSize: 14.0, color: Colors.blueAccent,
                              overflow: TextOverflow.ellipsis,)
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: Container(
                      child: Text(DateFormat("HH:mm:ss").format((infoTime).toDate()) , style: const TextStyle(
                          fontSize: 12.0, color: Colors.black45)
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  Widget _myhiddenContainer(Color infoColor){
    return Container(
      height: MediaQuery.of(context).size.height,
      color: infoColor,
      child: Row(
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: IconButton(
              icon: const Icon(FontAwesomeIcons.solidTrashAlt, color: Colors.white,),
              onPressed: () {

              },
            ),
          ),
          // Align(
          //   alignment: Alignment.centerRight,
          //   child: IconButton(
          //     icon: const Icon(FontAwesomeIcons.archive, color: Colors.white,),
          //     onPressed: () {
          //
          //     },
          //   ),
          // )
        ],
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(

      body: SafeArea(
        child: Column(
          children: [
            Container(
              height: 70,
              width: MediaQuery.of(context).size.width,
              decoration: const BoxDecoration(
                color: Color(0xff5a340b),
                  gradient: LinearGradient(
                colors: [Color(0xff0d70fe),Color(0xff2da9ef)],
                begin: Alignment.centerRight,
                end: Alignment(-1.0,-1.0)
              )
              ),
              child: _myheaderContent(),
            ),
            FutureBuilder<QuerySnapshot>(
                future: information.get(),
                builder:
                    (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (snapshot.hasError) {
                    return const Text("Something went wrong");
                  }

                  // if (snapshot.hasData && !snapshot.data!.exists) {
                  //   return const Text("Document does not exist");
                  // }

                  if (snapshot.connectionState == ConnectionState.done) {
                    final List<DocumentSnapshot> documents = snapshot.data!.docs;
                    return Flexible(
                      child: ListView(
                        shrinkWrap: true,
                          children: documents
                              .map((doc) {
                                  return Dismissible(
                                    direction: DismissDirection.startToEnd,
                                    key: Key(doc["title"].toString()),
                                    background: InkWell(
                                        onTap: (){

                                          // Navigator.push(context, MaterialPageRoute(builder: (context){
                                          //
                                          // }));

                                        },
                                        child: _myhiddenContainer(Colors.red)),
                                    child: _myListContainer(doc["title"], doc["body"],
                                        doc["createdAt"], Colors.blue),
                                    onDismissed: (direction){
                                      if(direction == DismissDirection.startToEnd){
                                        ScaffoldMessenger.of(context).showSnackBar(
                                            const SnackBar(content: Text("Delete"))
                                        );
                                      }
                                      if(documents.contains(documents.removeAt(documents.indexOf(doc)))){
                                        setState(() {
                                          // info.remove(info.removeAt(position));
                                        });
                                      }else{
                                        if(direction == DismissDirection.endToStart){
                                          ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(content: Text("Archive"))
                                          );
                                        }
                                      }
                                    },
                                  );

                              }
                          )
                              .toList()),
                    );
                  }
                  return const Center(
                      child:  CircularProgressIndicator()
                  );

              }
            )
          ],
          //  Container(
          //   color: Colors.white,
          //   width: 390,
          //   height: MediaQuery.of(context).size.height/1.5,
          //   child: ListView.builder(
          //       itemCount: info.length,
          //       itemBuilder: (context,position){
          //         return Dismissible(
          //           direction: DismissDirection.startToEnd,
          //           key: Key(info[position].toString()),
          //           background: _myhiddenContainer(info[position].status),
          //           child: _myListContainer(info[position].infoName, info[position].subInfo,
          //               info[position].infoTime, info[position].status),
          //           onDismissed: (direction){
          //             if(direction == DismissDirection.startToEnd){
          //               ScaffoldMessenger.of(context).showSnackBar(
          //                   const SnackBar(content: Text("Delete"))
          //               );
          //             }
          //             if(info.contains(info.removeAt(position))){
          //               setState(() {
          //                 info.remove(info.removeAt(position));
          //               });
          //             }else{
          //               if(direction == DismissDirection.endToStart){
          //                 ScaffoldMessenger.of(context).showSnackBar(
          //                     const SnackBar(content: Text("Archive"))
          //                 );
          //               }
          //             }
          //           },
          //         );
          //       }),
          // ),
        ),
      ),
    );
  }
  Future  _showDialog(){
    return
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text("Congrats!"),
          content: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.check_circle,
                color: Colors.green,
                size: 100.0,
              ),
              SizedBox(height: 10.0),
              Text("Payment Successful!"),
            ],
          ),
          actions: <Widget>[
            TextButton(
                onPressed: ()=> Navigator.pushNamed(context, ParkingListPage.routeName),

                child: const Text('OK'))
          ],
        ),
      );

  }
}
