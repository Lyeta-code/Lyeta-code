//
//
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
//
// import '../../components/app_text.dart';
//
// class selectVehicle extends StatelessWidget{
//   final formKey;
//
//    const selectVehicle({super.key, this.formKey});
//
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 10),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               AppText(text: "Select Vehicle",size: 21),
//               Padding(
//                 padding: const EdgeInsets.only(right: 10),
//                 child: InkWell(
//                     onTap: (){
//                       showDialog(
//                           context: context,
//                           builder: (_) =>  AlertDialog(
//                             content: Column(
//                               mainAxisSize: MainAxisSize.min,
//                               children: [
//                                 Form(
//                                   key: formKey,
//                                   child: Column(
//                                     children: [
//                                       TextFormField(
//                                         keyboardType: TextInputType.name,
//                                         onSaved: (newValue) =>
//                                             setState(() {
//                                               vehicleName = newValue!;
//                                             })
//                                         ,
//                                         onChanged: (value) {
//                                           if (value.isNotEmpty) {
//                                             removeError(error: kEmailNullError);
//                                           } else if (emailValidatorRegExp.hasMatch(value)) {
//                                             removeError(error: kInvalidEmailError);
//                                           }
//                                           return;
//                                         },
//                                         validator: (value) {
//                                           if (value!.isEmpty) {
//                                             addError(error: kNamelNullError);
//                                             return "";
//                                           }
//                                           return null;
//
//                                         },
//                                         decoration: const InputDecoration(
//                                           labelText: "Vehicle Name",
//                                           hintText: "Enter the Name of Vehicle",
//                                           // If  you are using latest version of flutter then lable text and hint text shown like this
//                                           // if you r using flutter less then 1.20.* then maybe this is not working properly
//                                           floatingLabelBehavior: FloatingLabelBehavior.always,
//                                           suffixIcon: Icon(Icons.car_crash_outlined),
//                                         ),
//                                       ),
//                                       const SizedBox(height: 20),
//                                       TextFormField(
//
//                                         onSaved: (newValue) => setState(() {
//                                           vehicleRegNo = newValue!;
//                                         }) ,
//                                         onChanged: (value) {
//                                           if (value.isNotEmpty) {
//                                             removeError(error: "Please Enter Your Car's Registration No");
//                                           }
//                                           return;
//                                         },
//                                         validator: (value) {
//                                           if (value!.isEmpty) {
//                                             addError(error: "Please Enter Your Car's Registration No");
//                                             return "";
//                                           }
//                                           return null;
//                                         },
//                                         decoration: const InputDecoration(
//                                           labelText: "Vehicle's Registration No",
//                                           hintText: "Enter your Registration No",
//                                           // If  you are using latest version of flutter then lable text and hint text shown like this
//                                           // if you r using flutter less then 1.20.* then maybe this is not working properly
//                                           floatingLabelBehavior: FloatingLabelBehavior.always,
//                                           suffixIcon: Icon(Icons.app_registration_outlined),
//                                         ),
//                                       ),
//                                       const SizedBox(height: 20),
//                                       FormError(errors: errors),
//                                       SingleChildScrollView(
//                                         scrollDirection: Axis.horizontal,
//                                         child: Wrap(
//                                           // spacing: 1.0,
//                                           children: List.generate(vehicle.length, (index){
//                                             return InkWell(
//                                               onTap: (){
//                                                 setState(() {
//
//                                                   vehicleImage = "assets/images/${vehicle.keys.elementAt(index)}";
//                                                   vehicleName = vehicle.values.elementAt(index);
//                                                   selectedIndexImage = index;
//                                                   // mobilePay = payment.values.elementAt(index);
//                                                 });
//
//                                                 // Navigator.pop(context);
//                                               },
//                                               child: Card(
//                                                 color: selectedIndexImage==index?Colors.lightGreen:Colors.red,
//                                                 child: Container(
//                                                     padding: const EdgeInsets.symmetric(horizontal: 13,vertical: 8),
//                                                     decoration: const BoxDecoration(
//
//                                                     ),
//                                                     margin: const EdgeInsets.only(right: 10),
//                                                     child: Column(
//                                                       children: [
//                                                         Image.asset("assets/images/${vehicle.keys.elementAt(index)}"
//                                                           ,height: 90,fit: BoxFit.fill,),
//                                                         // AppText(text: vehicle.values.elementAt(index))
//                                                       ],
//                                                     )
//                                                 ),
//                                               ),
//                                             );
//                                           }),
//                                         ),
//                                       ),
//                                       const SizedBox(height: 16),
//                                       ElevatedButton(
//                                         onPressed: () {
//                                           if (_formKey.currentState!.validate()) {
//
//                                           }
//                                         },
//                                         child: const Text("Continue"),
//                                       ),
//                                     ],
//                                   ),
//
//                                 ),
//
//                               ],
//                             ),
//                           ));
//                     },
//                     child: AppText(text: "Change",color: Colors.lightGreen,size: 20,)),
//               )
//             ],
//           ),
//         ),
//         Card(
//           elevation: 5,
//           child: Container(
//             padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 0),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Column(
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   children: [
//                     AppText(text: vehicleName,size: 16),
//                     AppText(text: vehicleRegNo,size: 14),
//                   ],
//                 ),
//                 Image.asset(vehicleImage,
//                   fit: BoxFit.cover,
//                   width: 120,)
//               ],
//             ),
//           ),
//         )
//       ],
//     ),
//   }
//
// }