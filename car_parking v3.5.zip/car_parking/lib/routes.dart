



import 'package:car_parking/screens/booking_screens/book_slot_page.dart';
import 'package:car_parking/screens/forgot_password/forgot_password_screen.dart';
import 'package:car_parking/screens/homepage_screen/homepage.dart';
import 'package:car_parking/screens/map_screen/parking_maps.dart';
import 'package:car_parking/screens/notification_screen/notificationPage.dart';
import 'package:car_parking/screens/notification_screen/notification_info.dart';
import 'package:car_parking/screens/parkingList_screen/parkinglist.dart';
import 'package:car_parking/screens/parking_overview/parking_screen.dart';
import 'package:car_parking/screens/payment_screen/mastercard_page.dart';
import 'package:car_parking/screens/payment_screen/mobile.dart';
import 'package:car_parking/screens/sign_in/sign_in_screen.dart';
import 'package:car_parking/screens/sign_up/sign_up_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/widgets.dart';

// We use name route
// All our routes will be available here
final Map<String, WidgetBuilder> routes = {
  SignInScreen.routeName: (context) =>  SignInScreen(),
  SignUpScreen.routeName: (context) => const SignUpScreen(),
  ForgotPasswordScreen.routeName: (context) => const ForgotPasswordScreen(),
  Parking.routeName: (context)=> const Parking(),
  ParkingMaps.routeName:(context)=>  ParkingMaps(identity: '',),
  ParkingListPage.routeName:(context)=> const ParkingListPage(),
  BookSlot.routeName:(context)=> BookSlot(location: const GeoPoint(2.5080481459689117,32.90080090150512 ),),
  InfoPage.routeName:(context)=> const InfoPage(),
  NotificationInfo.routeName:(context) => const NotificationInfo(),
  MobilePay.routeName:(context) =>  MobilePay(duration: '', price: 0, paymentMode: '', identity: '', slot: '', stime: DateTime.now(), etime: DateTime.now(), location: GeoPoint(0, 0), user: '', pBlock: '', parking: '',),
  MasterCardPage.routeName:(context)=> const MasterCardPage(),
  HomepageScreen.routeName: (context)=> const HomepageScreen(),
  // OtpScreen.routeName: (context) => const OtpScreen(),
  // HomeScreen.routeName: (context) => const HomeScreen(),
  // ProfileScreen.routeName: (context) => const ProfileScreen(),
};
