package com.example.car_parking;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
